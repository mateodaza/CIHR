var Hapi = require('hapi');
var Path = require('path');
var mysql = require('mysql');
var server = new Hapi.Server();
server.connection( { port:3000});
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '951401',
  database : 'proyect'
});

var codigo = '200045678';
 var password = '123456';
   server.route({
   connection.connect();
     method: 'GET',
     path: '/',
     handler: function(request,reply){
     connection.query('SELECT funcionario_est FROM Funcionario WHERE funcionario_cod= '+codigo+ ' AND funcionario_pwd = '+password+ ' ', function(err, rows, fields) {
    if (err) throw err;

    if( rows[0].funcionario_est == 1){
      reply('EL usuario puede logear');

    }else{
    reply(" el usuario no puede logear");
    }
connection.pause();
    });
    }
  });



server.start( function(){
console.log('Servidor Activo');
});
