# Children's International Recursos Humanos

## Instrucciones:
- npm install
- npm run build
- npm start

## Si lo anterior falla:
- sudo npm start

Luego conectarse a localhost desde cualquier navegador.

## Notas:
El codigo del backend esta en **server/**. El codigo del frontend esta en **public/**.
