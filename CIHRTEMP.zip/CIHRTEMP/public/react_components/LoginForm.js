
import React from 'react'

export default React.createClass({



  render() {
    return (
              <form onSubmit={this.handleSubmit} align="center">
                  <h1>Login</h1>
                  CodigoID: <input type="text" name="codigo" /> <br/><br/>
                  Contrasena: <input type="text" name="password" /> <br/><br/>
                <button className='button button-blue' name="submit_button">
                    <b>submit</b>
                  </button>
                  <br/><br/>
              </form>
          )
     } ,

     handleSubmit (evt) {
       evt.preventDefault();
       fetch('http://localhost:8080/api/v1/login/form', {
         method: 'POST',
         headers: {
           'Content-Type': 'application/json',
         },
         body: JSON.stringify({
           codigo: evt.target.codigo.value,
           password: evt.target.password.value,
         }),
       })
       .then(response => {
         if (response.ok) {
           console.log('OK');
         } else {
           throw new Error(response);
         }
       })
       .catch(error => {
         console.log(error);
         console.log('Ocurrio un error');
       });
     }




   });
