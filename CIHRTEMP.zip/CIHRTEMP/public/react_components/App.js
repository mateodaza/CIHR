import React from 'react'
import NavLink from './NavLink'

export default React.createClass({
  render() {
    return (
      <div>
        <h1>React Router Tutorial </h1>
        <ul role="nav">
        <li><NavLink to="/">Login</NavLink></li>
          <li><NavLink to="/abouts">Abouts</NavLink></li>
          <li><NavLink to="/repos">Repos</NavLink></li>
          <li><NavLink to="/form">Formulario</NavLink></li>
          <li><NavLink to="/home" onlyActiveOnIndex={true}>Home</NavLink></li>
        </ul>
        {this.props.children}
      </div>
    )
  }
})
