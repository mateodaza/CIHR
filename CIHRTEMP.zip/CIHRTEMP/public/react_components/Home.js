// modules/Home.js
import React from 'react'

export default React.createClass({
  render() {
    return <div>Seleccione Opcion</div>
  }
})
